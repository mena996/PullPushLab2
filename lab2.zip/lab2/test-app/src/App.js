import React, { useState, useEffect } from 'react';
import axios from 'axios'
import io from 'socket.io-client'




function App() {
  const socket = io.connect('http://localhost:5000');
  const [messages, setMessage] = useState([]);
  const [messages2, setMessage2] = useState([]);
  const [content, setContent] = useState([]);
  const [user, setUser] = useState([]);
  const handleChange = (e) => {
    const { target: { value } } = e;
    setContent(value);
  }
  const handleChangeUser = (e) => {
    const { target: { value } } = e;
    setUser(value);
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/messages', { content, user }).then(() => { setUser(''); setContent(''); }); //for normal request
    socket.emit('message', { content, user }); //for socket
  }
  //socket
  useEffect(() => {
    socket.on('new-message', (newMsg) => setMessage(messages => messages.concat(newMsg)));
  }, []);

  //server send event
  useEffect(() => {
    //get all data
    axios.get('http://localhost:5000/messages')
      .then((res) => {
        setMessage2(res.data);
        // subscribe(res.data);
      }
      );
    //subscribe for any changes
    const subscribe = new EventSource('http://localhost:5000/subscribe');
    subscribe.onmessage = (e) => {
      const data = JSON.parse(e.data);
      setMessage2((messages2) => messages2.concat(data));
    }
  }, []);


  return (
    <div className="container col-12 row">
      <div className="col-12">
        <form id="form" onSubmit={handleSubmit}>
          <input id="user" type="text" name="user" onChange={handleChangeUser} value={user}></input>
          <input id="content" type="text" name="content" onChange={handleChange} value={content}></input>
          <button type="submit" >send</button>
        </form>
      </div>
      <div className="container col-6 row alert-danger">
        <h1 className="col-12"><strong>web socket</strong></h1>
        {messages.map(m => <div key={Math.ceil(Math.random() * 100000)} className="card m-1 col-5">
          <div className="card-body">
            <h1><strong>user:</strong>{m.user}</h1>
            <h2><strong>body:</strong>{m.content}</h2>
          </div>
        </div>)}
      </div>
      <div className="container col-6 row alert-primary">
        <h1 className="col-12"><strong>server send event</strong></h1>
        {messages2.map(m => <div key={Math.ceil(Math.random() * 100000)} className="card m-1 col-5">
          <div className="card-body">
            <h1><strong>user:</strong>{m.user}</h1>
            <h2><strong>body:</strong>{m.content}</h2>
          </div>
        </div>)}
      </div>
    </div>
  );
}

export default App;
